package com.example.pigdicegame;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Locale;
import java.util.Random;

/**
 *
 * This is a class to allow you to play "Pig!" The dice game against a computer. Roll as many times as you wish, adding up your round score until you decide to hold. If you roll a 1
 * your round is over and your score for that round is 0. First to 100 wins!
 *
 * After game is over, you're given the option to play gain or quit.
 *
 * @author Evan Rogers.
 * @version 1.32
 *
 *
 */

public class Game {
    private final MainActivity mActivity;
    protected static final long COMPUTER_DELAY = 1000;
    private static final int WINNING_SCORE = 100;
    private final int zeroTotal;
    private final Button rollButton, holdButton;
    private final HashMap<String, Drawable> diceMap;
    private final Random random;
    private int userScore, computerScore, turnTotal;
    private boolean userStartGame;
    private boolean isUserTurn;
    private String imageName;
    private Thread computerThread;
    private final TextView compScore, myScore, dispTurnTotal;
    private final ImageView imageView;

    public Game(MainActivity activity) {
        userScore = 0; computerScore = 0; turnTotal = 0; zeroTotal = 0;
        mActivity = activity;
        imageName = "roll";
        computerThread = null;
        isUserTurn = true;
        userStartGame = true;
        compScore = mActivity.findViewById(R.id.compScore);
        myScore = mActivity.findViewById(R.id.myScore);
        dispTurnTotal = mActivity.findViewById(R.id.dispTurnTotal);
        rollButton = mActivity.findViewById(R.id.buttonRoll);
        holdButton = mActivity.findViewById(R.id.buttonHold);
        imageView = mActivity.findViewById(R.id.imageView);
        diceMap = new HashMap<>();
        diceMap.put("roll", mActivity.getResources().getDrawable(R.drawable.dice3));
        diceMap.put("hold", mActivity.getResources().getDrawable(R.drawable.hold));
        diceMap.put("die1", mActivity.getResources().getDrawable(R.drawable.die1));
        diceMap.put("die2", mActivity.getResources().getDrawable(R.drawable.die2));
        diceMap.put("die3", mActivity.getResources().getDrawable(R.drawable.die3));
        diceMap.put("die4", mActivity.getResources().getDrawable(R.drawable.die4));
        diceMap.put("die5", mActivity.getResources().getDrawable(R.drawable.die5));
        diceMap.put("die6", mActivity.getResources().getDrawable(R.drawable.die6));
        random = new Random();
    }

    /**
     *
     * This method is called when the roll button is pushed, or when the computer rolls.
     * It simulates rolling a 6 sided die. If a 1 is rolled the turn is changed automatically.
     *
     */
    public void roll() {
        int endTurnRoll = 1;

        int roll = random.nextInt(6) + endTurnRoll;
        setImage("die" + roll);
        if (roll == endTurnRoll) {
            setTurnTotal(zeroTotal);
            changeTurn();
        }
        else {
            setTurnTotal(turnTotal + roll);
        }
    }

    /**
     *
     * This method is called when the hold button is pushed or when the computer holds.
     * It holds your round score and adds it to the total score. It checks to see if either player has won.
     * Also passes the turn on to the other player if there is no winner.
     *
     */
    public void hold() {
        setImage("hold");
        if (isUserTurn)
            setUserScore(userScore + turnTotal);
        else
            setComputerScore(computerScore + turnTotal);
        setTurnTotal(zeroTotal);
        if (userScore >= WINNING_SCORE || computerScore >= WINNING_SCORE)
            endGame();
        else
            changeTurn();
    }

    /**
     *
     * This method is used to change the variable isUserTurn to true or false to change who's turn
     * it is in the game. It also updates the button state for which turn it is.
     *
     */
    public void changeTurn() {
        isUserTurn = !isUserTurn;
        setButtonsState();
    }

    /**
     *
     * This method is the computer player part of the game. It uses the "End race or keep pace" winning strategy.
     *
     */
    public void startComputerThread() {
        double divNumber = 8.0;
        int holdScore = 71;
        if (computerThread == null) {
            computerThread = new Thread(new Runnable() {
                public void run() {
                    while (true) {
                        Thread.yield();
                        try {Thread.sleep(COMPUTER_DELAY);} catch (InterruptedException e) {break;}
                        if (!isUserTurn && userScore < WINNING_SCORE && computerScore < WINNING_SCORE) {
                            int holdValue = 21 + (int) Math.round((userScore - computerScore) / divNumber);
                            if (!(computerScore + turnTotal >= WINNING_SCORE) &&
                                    (userScore >= holdScore || computerScore >= holdScore || turnTotal < holdValue))
                                mActivity.runOnUiThread(new Runnable() {public void run() {roll();}});
                            else {
                                mActivity.runOnUiThread(new Runnable() {public void run() {hold();}});
                            }
                        }
                    }
                }
            });
            computerThread.start();
        }
    }

    /**
     *
     * This method ends the game. It displays who won, and gives you the option to play again or quit.
     *
     */
    private void endGame() {
        String message = (!isUserTurn)
                ? String.format(Locale.getDefault(), "The computer wins %d to %d.", computerScore, userScore)
                : String.format(Locale.getDefault(), "You win %d to %d.", userScore, computerScore);
        message += " Would you like to play again?";
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("New Game", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        setUserScore(zeroTotal);
                        setComputerScore(zeroTotal);
                        setTurnTotal(zeroTotal);
                        userStartGame = !userStartGame;
                        isUserTurn = userStartGame;
                        setButtonsState();
                        setImage("roll");
                        dialog.cancel();
                    }
                })
                .setNegativeButton("Quit", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        computerThread.interrupt();
                        mActivity.finish();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public void setButtonsState() {
        holdButton.setEnabled(isUserTurn);
        rollButton.setEnabled(isUserTurn);
    }
    public void setUserScore(final int newScore) {
        userScore = newScore;
        myScore.setText(String.valueOf(newScore));
    }
    public void setComputerScore(final int newScore) {
        computerScore = newScore;
        compScore.setText(String.valueOf(newScore));
    }
    public void setTurnTotal(final int newTotal) {
        turnTotal = newTotal;
        dispTurnTotal.setText(String.valueOf(newTotal));
    }
    public void setImage(final String newImageName) {
        imageName = newImageName;
        imageView.setImageDrawable(diceMap.get(imageName));
    }
}
