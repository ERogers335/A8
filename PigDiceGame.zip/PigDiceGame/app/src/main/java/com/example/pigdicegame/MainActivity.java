package com.example.pigdicegame;

import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Game game = new Game(MainActivity.this);
        Button rollButton = findViewById(R.id.buttonRoll);
        Button holdButton = findViewById(R.id.buttonHold);

        rollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {game.roll();}
        });

        holdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {game.hold();}
        });

        game.startComputerThread();
    }
}